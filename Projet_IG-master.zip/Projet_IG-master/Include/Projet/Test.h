#pragma once
class CTest
{
public:
	CTest();
	~CTest();
};

